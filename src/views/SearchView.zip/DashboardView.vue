<script setup>
import { ref, onMounted } from 'vue'

const profiles = ref([])
const loading = ref(true)
const error = ref('')

async function loadProfiles() {
  loading.value = true
  error.value = ''

  try {
    const response = await fetch('/api/browse', {
      method: 'GET',
      credentials: 'include'
    })

    const data = await response.json()

    if (!response.ok) {
      error.value = data.error || data.message || 'Could not load profiles'
      return
    }

    profiles.value = data.users || data.profiles || data
  } catch (err) {
    error.value = 'Could not connect to backend.'
  } finally {
    loading.value = false
  }
}

async function likeProfile(profile) {
  try {
    const response = await fetch(`/api/like/${profile.id}`, {
      method: 'POST',
      credentials: 'include'
    })

    const data = await response.json()

    if (!response.ok) {
      alert(data.error || data.message || 'Could not like profile')
      return
    }

    profiles.value = profiles.value.filter((p) => p.id !== profile.id)
  } catch (err) {
    alert('Could not connect to backend.')
  }
}

async function passProfile(profile) {
  try {
    const response = await fetch(`/api/pass/${profile.id}`, {
      method: 'POST',
      credentials: 'include'
    })

    const data = await response.json()

    if (!response.ok) {
      alert(data.error || data.message || 'Could not pass profile')
      return
    }

    profiles.value = profiles.value.filter((p) => p.id !== profile.id)
  } catch (err) {
    alert('Could not connect to backend.')
  }
}

onMounted(() => {
  loadProfiles()
})
</script>

<template>
  <h2 class="page-title">Dashboard</h2>

  <p class="text-muted">
    Suggested profiles based on your preferences.
  </p>

  <p v-if="loading" class="alert alert-info">
    Loading profiles...
  </p>

  <p v-if="error" class="alert alert-danger">
    {{ error }}
  </p>

  <p v-if="!loading && !error && profiles.length === 0" class="alert alert-warning">
    No suggested profiles available right now. 
  </p>

  <div class="row">
    <div
      v-for="profile in profiles"
      :key="profile.id"
      class="col-md-4 mb-4"
    >
      <div class="card h-100">
        <img
          :src="profile.photo || profile.avatar || 'https://placehold.co/600x400?text=Profile'"
          class="card-img-top profile-img"
          alt="Profile photo"
        />

        <div class="card-body">
          <h4>
            {{ profile.username || profile.name || profile.handle }}
            <span v-if="profile.age">, {{ profile.age }}</span>
          </h4>

          <p class="text-muted" v-if="profile.location">
            <i class="bi bi-geo-alt"></i>
            {{ profile.location }}
          </p>

          <p>
            {{ profile.bio || profile.description || 'No bio added yet.' }}
          </p>

          <div class="mb-3" v-if="profile.interests">
            <span
              v-for="interest in profile.interests"
              :key="interest"
              class="badge bg-primary me-1"
            >
              {{ interest }}
            </span>
          </div>

          <button class="btn btn-success me-2" @click="likeProfile(profile)">
            <i class="bi bi-heart-fill"></i>
            Like
          </button>

          <button class="btn btn-outline-secondary" @click="passProfile(profile)">
            Pass
          </button>
        </div>
      </div>
    </div>
  </div>
</template>